//
//  BaseView.m
//  UISearchController1
//
//  Created by oule on 16/10/12.
//  Copyright © 2016年 ding juanjuan. All rights reserved.
//

#import "BaseView.h"


static BaseView *_payPasswordView;

@interface BaseView ()
{
  UIView  *_v;

}
@property (weak, nonatomic) IBOutlet UIView *baseview;
@property (weak, nonatomic) IBOutlet UIView *oneview;
@property (weak, nonatomic) IBOutlet UIView *twoview;
@property (weak, nonatomic) IBOutlet UIView *threeview;
@property (weak, nonatomic) IBOutlet UIView *fourview;

@end

@implementation BaseView


- (id)init
{
    if (self=[super init]) {
        self = [self initPayPasswordView];
    }
    return self;
}

- (id)initPayPasswordView
{
    if (self = [super init]) {
        
        _v = [[NSBundle mainBundle] loadNibNamed:@"BaseView" owner:self options:nil][0];
        _v.frame = [UIScreen mainScreen].bounds;
        self.frame = [UIScreen mainScreen].bounds;
        [self addSubview:_v];
        
    }
    return self;
}
- (void)tz_showPayPasswordViewInView:(UIView *)view fromController:(UIViewController *)fromController{
    self.fourview.hidden = YES;
    self.twoview.hidden = NO;
    self.threeview.hidden = YES;
    self.oneview.hidden = YES;
    UIWindow *win = [UIApplication sharedApplication].keyWindow;
    [win addSubview:self];

}
/** !!!:动画效果 */
- (void)transitionWithType:(NSString *) type WithSubtype:(NSString *) subtype ForView : (UIView *) view
{/*
  typedef enum : NSUInteger {
  Fade = 1,                   //淡入淡出
  Push,                       //推挤
  Reveal,                     //揭开
  MoveIn,                     //覆盖
  Cube,                       //立方体
  SuckEffect,                 //吮吸
  OglFlip,                    //翻转
  RippleEffect,               //波纹
  PageCurl,                   //翻页
  PageUnCurl,                 //反翻页
  CameraIrisHollowOpen,       //开镜头
  CameraIrisHollowClose,      //关镜头
  CurlDown,                   //下翻页
  CurlUp,                     //上翻页
  FlipFromLeft,               //左翻转
  FlipFromRight,              //右翻转
  
  } AnimationType;
  */
    CATransition *animation = [CATransition animation];
    animation.duration = 0.3;
    animation.type = type;
    if (subtype != nil) {
        //设置子类
        animation.subtype = subtype;
    }
    //设置运动速度 UIViewAnimationOptionCurveEaseInOut
    //    animation.timingFunction = [CAMediaTimingFunction functionWithControlPoints:0.2 :0.03 :0.13 :1.0];
    [view.layer addAnimation:animation forKey:@"animation"];
}

- (IBAction)selecabank:(id)sender {
     self.oneview.hidden = self.threeview.hidden = self.fourview.hidden = YES;
    self.twoview.hidden = NO;
     [self transitionWithType:kCATransitionPush WithSubtype:kCATransitionFromRight ForView:self.baseview];

}

- (IBAction)pay:(id)sender {//intwo
    self.oneview.hidden = self.twoview.hidden = self.fourview.hidden = YES;
    self.threeview.hidden = NO;
     [self transitionWithType:kCATransitionPush WithSubtype:kCATransitionFromRight ForView:self.baseview];
}


- (IBAction)banckone:(id)sender {
    self.twoview.hidden = self.threeview.hidden = self.fourview.hidden = YES;
    self.oneview.hidden = NO;
    [self transitionWithType:kCATransitionPush WithSubtype:kCATransitionFromLeft ForView:self.baseview];
}

- (IBAction)threebackone:(id)sender {
    self.twoview.hidden = self.threeview.hidden = self.fourview.hidden = YES;
    self.oneview.hidden = NO;
    [self transitionWithType:kCATransitionPush WithSubtype:kCATransitionFromLeft ForView:self.baseview];
}


- (IBAction)infour:(id)sender {
    self.twoview.hidden = self.threeview.hidden = self.oneview.hidden = YES;
    self.fourview.hidden = NO;
     [self transitionWithType:kCATransitionPush WithSubtype:kCATransitionFromRight ForView:self.baseview];
}


- (IBAction)backthree:(id)sender {
    self.twoview.hidden = self.fourview.hidden = self.oneview.hidden = YES;
    self.threeview.hidden = NO;
    [self transitionWithType:kCATransitionPush WithSubtype:kCATransitionFromLeft ForView:self.baseview];
    
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.baseview removeFromSuperview];
     [self removeFromSuperview];
}

@end
