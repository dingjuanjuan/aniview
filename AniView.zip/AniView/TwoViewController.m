//
//  TwoViewController.m
//  UISearchController1
//
//  Created by oule on 16/10/11.
//  Copyright © 2016年 ding juanjuan. All rights reserved.
//

#import "TwoViewController.h"
#import "BaseView.h"

@interface TwoViewController ()

@end

@implementation TwoViewController


- (IBAction)back:(id)sender {
    BaseView *vie = [[BaseView alloc]init];
    [vie tz_showPayPasswordViewInView:self.view fromController:self];
}

@end
