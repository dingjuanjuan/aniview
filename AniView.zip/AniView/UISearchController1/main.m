//
//  main.m
//  UISearchController1
//
//  Created by oule on 16/10/11.
//  Copyright © 2016年 ding juanjuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
